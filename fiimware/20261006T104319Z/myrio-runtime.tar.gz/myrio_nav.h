#ifndef MYRIO_NAV_H
#define MYRIO_NAV_H

#include <stdint.h>

#if defined(_WIN32)
#define MRNAV_API __declspec(dllexport)
#else
#define MRNAV_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct mrnav_handle mrnav_handle;

enum mrnav_status {
    MRNAV_OK = 0,
    MRNAV_WARN_TRUNCATED = 1,
    MRNAV_ERR_INVALID_ARGUMENT = -1,
    MRNAV_ERR_OUT_OF_MEMORY = -2,
    MRNAV_ERR_INVALID_STATE = -3,
    MRNAV_ERR_LIDAR = -4,
    MRNAV_ERR_THREAD = -5,
    MRNAV_ERR_EXCEPTION = -6,
    MRNAV_ERR_IO = -7
};

enum mrnav_state {
    MRNAV_STATE_IDLE = 0,
    MRNAV_STATE_STARTING = 1,
    MRNAV_STATE_RUNNING = 2,
    MRNAV_STATE_GOAL_REACHED = 3,
    MRNAV_STATE_NO_PATH = 4,
    MRNAV_STATE_SENSOR_STALE = 5,
    MRNAV_STATE_LOCALIZATION_LOST = 6,
    MRNAV_STATE_FAULT = 7
};

enum mrnav_fault {
    MRNAV_FAULT_NONE = 0,
    MRNAV_FAULT_INVALID_ODOMETRY = 1,
    MRNAV_FAULT_ODOMETRY_TIME = 2,
    MRNAV_FAULT_LIDAR_START = 3,
    MRNAV_FAULT_LIDAR_READ = 4,
    MRNAV_FAULT_SCAN_STALE = 5,
    MRNAV_FAULT_LOCALIZATION = 6,
    MRNAV_FAULT_NO_PATH = 7,
    MRNAV_FAULT_GOAL_OUTSIDE_FIELD = 8,
    MRNAV_FAULT_INTERNAL = 9
};

enum mrnav_grid_value {
    MRNAV_GRID_UNKNOWN = 0,
    MRNAV_GRID_FREE = -2,
    MRNAV_GRID_OCCUPIED = 8
};

/*
 * Allocate a navigation instance. The port parameter is retained for ABI
 * compatibility but is ignored; LiDAR lifetime is managed through ydlv_*.
 */
MRNAV_API mrnav_handle *mrnav_create(const char *port);

/*
 * Configure the fixed 256 x 128 grid and controller. Call only while IDLE and
 * before the first mrnav_start(). Runtime map clearing is exclusive to
 * mrnav_reset_map().
 * All distances use meters, angles use radians, and velocities use SI units.
 */
MRNAV_API int32_t mrnav_configure(
    mrnav_handle *handle,
    float field_width_m,
    float field_height_m,
    float resolution_m,
    float robot_radius_m,
    float safety_margin_m,
    float lidar_x_m,
    float lidar_y_m,
    float lidar_yaw_rad,
    float max_velocity_mps,
    float max_angular_velocity_radps,
    float max_acceleration_mps2,
    float max_angular_acceleration_radps2,
    float lookahead_m,
    float goal_position_tolerance_m,
    float goal_yaw_tolerance_rad,
    float minimum_match_score);

/*
 * Start one goal-directed mapping and navigation run. The RAM map is retained.
 * The active YDLIDAR handle must already be running via ydlv_start().
 */
MRNAV_API int32_t mrnav_start(
    mrnav_handle *handle,
    float start_x_m,
    float start_y_m,
    float start_yaw_rad,
    float goal_x_m,
    float goal_y_m,
    float goal_yaw_rad);

/*
 * 100 Hz non-blocking hot path. timestamp_ns must be monotonic within the
 * caller's time domain. Pass zero to timestamp at function entry.
 */
MRNAV_API int32_t mrnav_control_step(
    mrnav_handle *handle,
    uint64_t timestamp_ns,
    float odom_x_m,
    float odom_y_m,
    float odom_yaw_rad,
    float odom_vx_mps,
    float odom_vy_mps,
    float odom_wz_radps,
    float *command_vx_mps,
    float *command_vy_mps,
    float *command_wz_radps,
    float *corrected_x_m,
    float *corrected_y_m,
    float *corrected_yaw_rad,
    int32_t *state,
    int32_t *fault);

/* Stop motion and the navigation worker while retaining the RAM map and LiDAR. */
MRNAV_API int32_t mrnav_cancel(mrnav_handle *handle);

/* Clear the RAM map. Valid only while IDLE or GOAL_REACHED. */
MRNAV_API int32_t mrnav_reset_map(mrnav_handle *handle);

/*
 * Copy signed log-odds cells in row-major order. The required capacity is
 * width * height. Grid metadata is returned even when the buffer is short.
 */
MRNAV_API int32_t mrnav_copy_grid(
    mrnav_handle *handle,
    int8_t *cells,
    int32_t capacity,
    int32_t *width,
    int32_t *height,
    float *resolution_m,
    float *origin_x_m,
    float *origin_y_m,
    uint32_t *generation);

MRNAV_API int32_t mrnav_get_status(
    mrnav_handle *handle,
    int32_t *state,
    int32_t *fault,
    float *match_score,
    float *known_fraction,
    int32_t *path_point_count,
    uint64_t *last_scan_age_ms,
    uint32_t *map_generation);

/*
 * Write the current mission's fixed-memory 100 Hz diagnostic trace as CSV.
 * Call only after the mission reaches a terminal state or after mrnav_cancel().
 * A terminal worker also writes /tmp/myrio_nav_trace.csv automatically.
 */
MRNAV_API int32_t mrnav_dump_trace_csv(
    mrnav_handle *handle,
    const char *path);

/* Copy the latest UTF-8 error. Passing NULL/0 queries the required byte count. */
MRNAV_API int32_t mrnav_get_last_error(
    mrnav_handle *handle,
    char *buffer,
    int32_t buffer_size);

/* Stop the worker and release navigation memory. LiDAR is not stopped. */
MRNAV_API int32_t mrnav_destroy(mrnav_handle *handle);

MRNAV_API const char *mrnav_version(void);

#ifdef __cplusplus
}
#endif

#endif

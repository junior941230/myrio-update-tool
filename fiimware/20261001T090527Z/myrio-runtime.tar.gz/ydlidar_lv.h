#ifndef YDLIDAR_LV_H
#define YDLIDAR_LV_H

#include <stdint.h>

#if defined(_WIN32)
#define YDLV_API __declspec(dllexport)
#else
#define YDLV_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ydlv_handle ydlv_handle;

enum ydlv_status {
    YDLV_OK = 0,
    YDLV_WARN_TRUNCATED = 1,
    YDLV_WARN_PARTIAL = 2,
    YDLV_ERR_INVALID_ARGUMENT = -1,
    YDLV_ERR_OUT_OF_MEMORY = -2,
    YDLV_ERR_INVALID_STATE = -3,
    YDLV_ERR_INITIALIZE = -4,
    YDLV_ERR_START = -5,
    YDLV_ERR_READ = -6,
    YDLV_ERR_EXCEPTION = -7
};

enum ydlv_wall_valid_mask {
    YDLV_WALL_LEFT_VALID = 1,
    YDLV_WALL_FRONT_VALID = 2,
    YDLV_WALL_RIGHT_VALID = 4,
    YDLV_WALL_ALL_VALID = 7
};

/*
 * Create an X4-configured wrapper. The default port is /dev/ttyUSB0 when port
 * is NULL or empty. This allocates memory but does not open the serial port.
 * Creating a new handle automatically stops, disconnects, and retires the
 * previous active handle in this process so an aborted LabVIEW VI can recover.
 */
YDLV_API ydlv_handle *ydlv_create_x4(const char *port);

/*
 * Borrow the current process-wide active handle. The caller does not own it.
 * Returns NULL until ydlv_create_x4 succeeds.
 */
YDLV_API ydlv_handle *ydlv_get_active_handle(void);

/* Initialize the official SDK, open the serial port, and start scanning. */
YDLV_API int32_t ydlv_start(ydlv_handle *handle);

/*
 * Read one complete revolution into caller-owned arrays.
 *
 * Only valid points in the inclusive range [min_limit_m, max_limit_m] are
 * copied. angles_rad, ranges_m and intensities must each contain at least
 * capacity float elements. point_count receives the number copied. The call
 * returns YDLV_WARN_TRUNCATED when more matching points exist than capacity.
 * This function may block for approximately one scan period or until the
 * official SDK's internal timeout expires.
 */
YDLV_API int32_t ydlv_read_scan(
    ydlv_handle *handle,
    float *angles_rad,
    float *ranges_m,
    float *intensities,
    int32_t capacity,
    float min_limit_m,
    float max_limit_m,
    int32_t *point_count,
    uint64_t *timestamp_ns,
    float *scan_frequency_hz,
    float *scan_time_s
);

/*
 * Extended scan API. It preserves every ydlv_read_scan behavior and also
 * returns the SDK's time increment between consecutive points. Point i was
 * acquired at timestamp_ns + i * time_increment_s.
 */
YDLV_API int32_t ydlv_read_scan_v2(
    ydlv_handle *handle,
    float *angles_rad,
    float *ranges_m,
    float *intensities,
    int32_t capacity,
    float min_limit_m,
    float max_limit_m,
    int32_t *point_count,
    uint64_t *timestamp_ns,
    float *scan_frequency_hz,
    float *scan_time_s,
    float *time_increment_s
);

/*
 * Estimate clearances from the robot outline to approximately flat walls on
 * its left, front, and right. This is a pure scan conversion function: it does
 * not read the LiDAR handle and does not depend on the navigation library.
 *
 * angles_rad uses the clockwise-positive convention returned by
 * ydlv_read_scan*. lidar_yaw_rad is the LiDAR's counter-clockwise-positive
 * mounting angle relative to robot forward. Each edge_offset_m is measured
 * from the LiDAR origin to that edge of the robot; pass zero for LiDAR-to-wall
 * distances. sector_half_width_rad must be in (0, pi/4), and minimum_points
 * must be positive.
 *
 * Output angles are robot-frame bearings: forward is zero and counter-clockwise
 * is positive. Missing directions return NaN for both distance and angle and
 * are omitted from valid_mask. Returns YDLV_WARN_PARTIAL unless all three
 * directions have enough valid points.
 */
YDLV_API int32_t ydlv_estimate_wall_distances(
    const float *angles_rad,
    const float *ranges_m,
    int32_t point_count,
    float lidar_yaw_rad,
    float sector_half_width_rad,
    int32_t minimum_points,
    float left_edge_offset_m,
    float front_edge_offset_m,
    float right_edge_offset_m,
    float *left_distance_m,
    float *front_distance_m,
    float *right_distance_m,
    float *left_angle_rad,
    float *front_angle_rad,
    float *right_angle_rad,
    int32_t *valid_mask
);

/* Stop scanning and close the SDK connection. Safe to call more than once. */
YDLV_API int32_t ydlv_stop(ydlv_handle *handle);

/* Stop, disconnect, and release the opaque handle. */
YDLV_API int32_t ydlv_destroy(ydlv_handle *handle);

/* Return 1 when scanning, otherwise 0. */
YDLV_API int32_t ydlv_is_running(ydlv_handle *handle, int32_t *running);

/*
 * Copy the latest error as UTF-8. The return value is the full byte length,
 * excluding the NUL terminator. Passing NULL/0 queries the required length.
 */
YDLV_API int32_t ydlv_get_last_error(
    ydlv_handle *handle,
    char *buffer,
    int32_t buffer_size
);

/* Static string owned by the library. Do not free it. */
YDLV_API const char *ydlv_wrapper_version(void);

#ifdef __cplusplus
}
#endif

#endif

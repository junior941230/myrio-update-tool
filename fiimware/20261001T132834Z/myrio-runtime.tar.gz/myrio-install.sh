#!/bin/sh
# Runs on the myRIO from an extracted myrio-runtime.tar.gz: run every test,
# and install only if all pass. Shipped inside the tarball so deploy tools do
# not need to know file names or test names.
set -eu
runtime=$(cd "$(dirname "$0")" && pwd)
cd "$runtime"
lidar_lib=libydlidar_lv.so.1.3.0
nav_lib=libmyrio_nav.so.2.0.0

ln -sfn "$lidar_lib" libydlidar_lv.so.1
ln -sfn "$nav_lib" libmyrio_nav.so.1
export LD_LIBRARY_PATH="$runtime"
# Test traces stay here so the last real mission trace in /tmp survives.
for test in lidar_smoke_test nav_abi_smoke_test nav_core_test nav_sim_test nav_performance_test; do
    echo "== $test"
    MRNAV_TRACE_PATH="$runtime/$test-trace.csv" "./$test"
done

# Install by rename: a running LabVIEW process keeps its mapped copy instead
# of crashing on a file overwritten in place.
install_file() {
    cp "$1" "$2/.$1.new"
    chmod "$3" "$2/.$1.new"
    mv -f "$2/.$1.new" "$2/$1"
}
mkdir -p /usr/local/lib /usr/local/include /usr/local/bin
install_file "$lidar_lib" /usr/local/lib 0755
install_file "$nav_lib" /usr/local/lib 0755
ln -sfn "$lidar_lib" /usr/local/lib/libydlidar_lv.so.1
ln -sfn libydlidar_lv.so.1 /usr/local/lib/libydlidar_lv.so
ln -sfn "$nav_lib" /usr/local/lib/libmyrio_nav.so.1
ln -sfn libmyrio_nav.so.1 /usr/local/lib/libmyrio_nav.so
install_file ydlidar_lv.h /usr/local/include 0644
install_file myrio_nav.h /usr/local/include 0644
for tool in ydlidar_lv_x4_probe ydlidar_lv_restart_probe nav_abi_smoke_test; do
    install_file "$tool" /usr/local/bin 0755
done
MRNAV_TRACE_PATH="$runtime/installed-smoke-trace.csv" LD_LIBRARY_PATH=/usr/local/lib \
    /usr/local/bin/nav_abi_smoke_test
echo "Deployment complete. Test artifacts retained at $runtime"
